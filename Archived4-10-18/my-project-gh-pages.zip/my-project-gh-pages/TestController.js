app.controller('TestController', function($scope) {
    $scope.message = 'Hello from TestController';
});
