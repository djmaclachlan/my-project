/**
 * Created by Adolf In Space on 12/4/2016.
 */
var React = require('react');
var ReactDOM = require('react-dom');

// Write code here:
ReactDOM.render(
<h1>Hello, world!</h1>,
    document.getElementById('app')
);