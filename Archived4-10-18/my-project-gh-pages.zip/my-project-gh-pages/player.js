/**
 * Created by NowWithLessVirus! on 7/17/16.
 */

var app = angular.module("myApp", []);
